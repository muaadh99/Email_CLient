package EmailClient;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;


//this class contains methods to check if a wish to a recipient is already sent or not

public class Email_Rec_Checker {
    // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
    static Date date;

    static {
        try {
            date = AlternativeMethods.toDaydate();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    //this method checks if a wish to a recipient is already sent or not
    public static boolean isSent(Date birthday , String email , String subject , ArrayList<Email> emailrecords){
        try{
            if(emailrecords != null) {
                for (Email i : emailrecords) {
                    if (i.getDate().getYear() == date.getYear() && i.getDate().getMonth() == birthday.getMonth() &&
                            i.getDate().getDate() == birthday.getDate() && Objects.equals(subject, i.getSubject()) &&
                            i.getRecipient().equals(email)) {
                        return false;
                    }
                }

            }

    }
        catch(NullPointerException e) {
            e.printStackTrace();
        }


        return true;
    }
}
