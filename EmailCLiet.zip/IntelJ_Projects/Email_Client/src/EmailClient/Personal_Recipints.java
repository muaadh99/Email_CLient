package EmailClient;

import java.io.Serializable;
import java.util.Date;

//class for Personal_Recipints
public class Personal_Recipints extends Recipients implements Serializable {
    Date birthday ;

    Date last_wished_date = null ;

    private String nickname ;

    public Date getBirthday() {
        return birthday;
    }

    public String getNickname() {
        return nickname;
    }



    public Personal_Recipints(String type, String name,String nickname , String email, Date birthday  ) {
        super(type, name, email);
        this.birthday = birthday;
        this.nickname = nickname;

    }
    public Date getLast_wished_year() {
        return last_wished_date;
    }

    public void setLast_wished_year(Date last_wished_year) {
        this.last_wished_date = last_wished_year;

    }
}

