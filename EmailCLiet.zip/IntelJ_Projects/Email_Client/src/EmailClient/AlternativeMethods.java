package EmailClient;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

public class AlternativeMethods {

    //method to nenewing previosly sent Email objects
    public static Email renewEmailRecords(Email emailrecords) throws ParseException {
        return (new Email(emailrecords.getDate() , emailrecords.getRecipient() , emailrecords.getSubject()));
    }

    public static Date toDaydate () throws ParseException {
        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        return Date.from(zonedDateTime.toInstant());

    }
    public static Date StringToDate(String datesrting) throws ParseException {
        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
        } catch (ParseException e) {
            System.out.println("Invalid date format");
        }
        return null;
    }
}
