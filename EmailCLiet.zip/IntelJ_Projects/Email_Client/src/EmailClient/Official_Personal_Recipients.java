package EmailClient;

import java.io.Serializable;
import java.util.Date;

//class for Official_Personal_Recipients
public class Official_Personal_Recipients extends Official_Recipients implements Serializable {

    Date birthday ;
    Date last_wished_date = null ;

    public Official_Personal_Recipients(String type, String name, String email, String designation , Date birthday ) {
        super(type, name, email, designation);
        this.birthday = birthday;
    }
    public Date getBirthday() {
        return birthday;
    }

    public Date getLast_wished_year() {
        return last_wished_date;
    }

    public void setLast_wished_year(Date last_wished_year) {
        this.last_wished_date = last_wished_year;
    }
}
