package EmailClient;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


//this class contains methods related to checking birthday is on a given date or not
public class Birthday_Checker {
    public static Date StringToDate(String datesrting) throws ParseException {
        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
        } catch (ParseException e) {
            System.out.println("Invalid date format");
        }
        return null;
    }

    //method to check if the birthday is on a given date or not
    public static boolean isBirthday(Date birthday, Date date) {
        if(date != null) {
            if (birthday.getMonth() == date.getMonth() && birthday.getDate() == date.getDate()) {
                return true;
            }
        }
        return false;
    }

    //method to return a list of recipients who have birthday on a given date
    public static ArrayList<Recipients> checkBirthday(ArrayList<Recipients> recipients , String Date) throws ParseException {
        Date date = StringToDate(Date);
        ArrayList<Recipients> recipients_list = new ArrayList<Recipients>();
        for (Recipients recipient : recipients) {
            if (recipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                if (isBirthday(newRecipient.birthday, date)) {
                    recipients_list.add(newRecipient);
                }
            } else if (recipient.getType().equals("Office_friend")) {
                Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                if (isBirthday(newRecipient.birthday, date)) {
                    recipients_list.add(newRecipient);
                }
            }
        }
        return recipients_list;
    }
}
