package EmailClient;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//This class contains methods for addind and renewing Recipient objects
public  class Add_Recipients {
    public static Date StringToDate(String datesrting) throws ParseException {
        return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
    }

    //method to create new Recipient objects
    public static Recipients addRecipients(String[] type_details, String[] name_email) throws ParseException {
        switch (type_details[0]) {
            case "Personal":
                return new Personal_Recipints(type_details[0], name_email[0], name_email[1], name_email[2],
                        StringToDate(name_email[3]) );

            case "Office_friend":
                return new Official_Personal_Recipients(type_details[0], name_email[0], name_email[1], name_email[2],
                        StringToDate(name_email[3]) );
            case "Official":
                return new Official_Recipients(type_details[0], name_email[0], name_email[1], name_email[2]);

            default:
                System.out.println("Invalid Recipient Type");

        }
        return null;
    }

    //method to nenewing the previously entered Recipient objects
    public static Recipients renewRecipients(Recipients pastRecipient) throws ParseException {
        if (pastRecipient.getType().equals("Personal")) {
            Personal_Recipints newRecipient = (Personal_Recipints) pastRecipient;
            return new Personal_Recipints(pastRecipient.getType(), pastRecipient.getName(),
                    ((Personal_Recipints) pastRecipient).getNickname(), pastRecipient.getEmail(),
                    ((Personal_Recipints) pastRecipient).getBirthday());

        } else if (pastRecipient.getType().equals("Office_friend")) {
            return new Official_Personal_Recipients(pastRecipient.getType(), pastRecipient.getName(),
                    pastRecipient.getEmail(), ((Official_Personal_Recipients)pastRecipient).getDesignation(),
                    ((Official_Personal_Recipients) pastRecipient).getBirthday() );

        } else if (pastRecipient.getType().equals("Official")) {
            return new Official_Recipients(pastRecipient.getType(), pastRecipient.getName(), pastRecipient.getEmail(),
                    ((Official_Recipients)pastRecipient).getDesignation());

        }

        return null;
    }



}
