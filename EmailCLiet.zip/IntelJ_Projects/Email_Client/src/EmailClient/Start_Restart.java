package EmailClient;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;

import static EmailClient.Birthday_Checker.isBirthday;


//this class contains methods for starting and restarting the program
public class Start_Restart {

    public static Date dateReturner() {
        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()


        return Date.from(zonedDateTime.toInstant());
    }

    //this method starts the program by recreating the previously saved Recipient objects
    public static void start(ArrayList<Recipients> recipients) throws ParseException, IOException, NullPointerException,
            ClassNotFoundException {


        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        Date date = dateReturner();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
        String strDate = formatter.format(date);
        ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, strDate);

        for (Recipients recipient : recipients_list) {
            restart(recipient);
        }

    }

    //this methods will check a given Recipient's bithday is on today and if it's today this will call the method to send the email
    // only if previously the wish hasn't been sent
    public static void restart(Recipients recipient) {
        try {
            if (recipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                        "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner());
                    if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                        EmailSender.EmailSendereng(newRecipient.getEmail(), "Hug and Love on Your Birthday " +
                                newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                    }
                }
            } else if (recipient.getType().equals("Office_friend")) {
                Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                        "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner());
                    if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                        EmailSender.EmailSendereng(newRecipient.getEmail(), "Wish you a Happy Birthday " +
                                newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                    }
                }
            }

        } catch (ParseException | IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}

