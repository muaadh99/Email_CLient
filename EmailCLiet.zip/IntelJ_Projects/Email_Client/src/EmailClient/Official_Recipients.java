package EmailClient;

import java.io.Serializable;

//class for Official_Recipients
public class Official_Recipients extends Recipients implements Serializable {


    private final String designation ;

    public Official_Recipients(String type, String name, String email, String designation) {
        super(type, name, email);
        this.designation = designation;
    }
    public String getDesignation() {
        return designation;
    }
}

