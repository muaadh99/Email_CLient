package EmailClient;

// your index number

//import libraries

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Objects;
import java.util.Scanner;

import static EmailClient.Serialize_Deserialize.Serialize;

//this is the main class
public class Email_Client {

    public static void main(String[] args) throws IOException, ParseException, ClassNotFoundException {
        System.out.println("Welcome to the Email Client\n" +
                "Please Be Patient Till Check and Send Wishes for Those who have birthday\n"  );
        ArrayList recipients = new ArrayList<>();
        String ClientPath = "D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\clientList.ser";
        try {
            File myObj = new File(ClientPath);
            if(myObj.length() != 0){
            recipients = (Serialize_Deserialize.Deserialize(ClientPath));
            }

        }
        catch (IOException | ClassNotFoundException i) {
            i.printStackTrace();
        }

        new EmailSender();
        Start_Restart.start(recipients);

        System.out.println("Ok All Set to Go");


        boolean start = true ;
        while (start) {
            Scanner scanner = null;
            scanner = new Scanner(System.in);
            System.out.println("\nEnter option type: \n"
                    + "1 - Adding a new recipient\n"
                    + "2 - Sending an email\n"
                    + "3 - Printing out all the recipients who have birthdays\n"
                    + "4 - Printing out details of all the emails sent\n"
                    + "5 - Printing out the number of recipient objects in the application\n"
                    + "6 - End the Programme\n");
            int option = 0;
            try {
                option = scanner.nextInt();

            } catch (InputMismatchException e) {
                System.out.println("Invalid Choice");
            }


            switch (option) {
                case 1:
                    // input format - Official: nimal,nimal@gmail.com,ceo
                    // Use a single input to get all the details of a recipient
                    // code to add a new recipient
                    // store details in clientList.txt file
                    // Hint: use methods for reading and writing files
                    System.out.println("input format - Official: nimal,nimal@gmail.com,ceo  or\n" +
                            "               Office_friend: kamal,kamal@gmail.com,clerk,2000/12/12   or\n" +
                            "               Personal: sunil,<nick-name>,sunil@gmail.com,2000/10/10\n");
                    String[] type_details;
                    String[] name_email;

                    Scanner sc = new Scanner(System.in);
                    String details = sc.nextLine();


                    type_details = details.split(": ");
                    try{
                    name_email = type_details[1].split(",");
                    }
                    catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Invalid Input");
                        break;
                    }

                    recipients.add(Add_Recipients.addRecipients(type_details, name_email));
                    Serialize(recipients);
                    Start_Restart.restart(Objects.requireNonNull(Add_Recipients.addRecipients(type_details, name_email)));
                    System.out.println("Recipient added successfully");

                    String Path1 = "D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\clientList.txt";
                    String newdetails = details + "\n";
                    Files.write(Paths.get(Path1), newdetails.getBytes(), StandardOpenOption.APPEND);

                    break;
                case 2:
                    // input format - email, subject, content
                    // code to send an email
                    System.out.println("input format - email, subject, content");
                    Scanner scnew = new Scanner(System.in);
                    String recipient = scnew.nextLine();
                    String[] recarray = recipient.split(", ");
                    try{
                    EmailSender.EmailSendereng(recarray[0], recarray[1], recarray[2]);
                    }
                    catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Invalid Input");
                        break;
                    }

                    break;
                case 3:
                    // input format - yyyy/MM/dd (ex: 2018/09/17)
                    // code to print recipients who have birthdays on the given date
                    System.out.println("input format - yyyy/MM/dd (ex: 2018/09/17)");
                    Scanner scc = new Scanner(System.in);
                    String date = scc.nextLine();
                    ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, date);

                    for (Recipients r : recipients_list) {
                        System.out.println(r.getName() + " " + r.getEmail());
                    }

                    break;
                case 4:
                    // input format - yyyy/MM/dd (ex: 2018/09/17)
                    // code to print the details of all the emails sent on the input date
                    System.out.println("input format - yyyy/MM/dd (ex: 2018/09/17)");
                    Scanner sccc = new Scanner(System.in);
                    String datee = sccc.nextLine();

                    if(AlternativeMethods.StringToDate(datee) == null){
                        break;
                    }

                    try {
                        for (Email e : EmailSender.getEmailrecords()) {

                            if (e.getDate().equals(Birthday_Checker.StringToDate(datee))) {
                                System.out.println(e.getRecipient() + " " + e.getSubject());
                            }
                        }
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    }

                    break;
                case 5:
                    // code to print the number of recipient objects in the application

                    System.out.println(recipients.size());
                    break;

                case 6:
                    start = false;
            }

            // start email client
            // code to create objects for each recipient in clientList.txt
            // use necessary variables, methods and classes

        }
    }
}
// create more classes needed for the implementation (remove the  public access modifier from classes when you submit your code)


