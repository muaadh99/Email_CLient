package EmailClient;

import java.io.Serializable;


//super class for recipients
public class Recipients implements Serializable {
    private String type;
    private String name ;
    private String email ;

    public Recipients(String type, String name, String email) {
        this.setType(type);
        this.setName(name);
        this.setEmail(email);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}
