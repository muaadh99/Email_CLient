
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;


//Index No – 200401J

    //this class contains methods for starting and restarting the program

    public static Date dateReturner() {
        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()


        return Date.from(zonedDateTime.toInstant());
    }

    //this method starts the program by recreating the previously saved Recipient objects
    public static void start(ArrayList<Recipients> recipients) throws ParseException, IOException, NullPointerException,
            ClassNotFoundException {


        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        Date date = dateReturner();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
        String strDate = formatter.format(date);
        ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, strDate);

        for (Recipients recipient : recipients_list) {
            restart(recipient);
        }

    }

    //this methods will check a given Recipient's bithday is on today and if it's today this will call the method to send the email
    // only if previously the wish hasn't been sent
    public static void restart(Recipients recipient) {
        try {
            if (recipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                        "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner());
                    if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                        EmailSender.EmailSendereng(newRecipient.getEmail(), "Hug and Love on Your Birthday " +
                                newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                    }
                }
            } else if (recipient.getType().equals("Office_friend")) {
                Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                        "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner());
                    if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                        EmailSender.EmailSendereng(newRecipient.getEmail(), "Wish you a Happy Birthday " +
                                newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                    }
                }
            }

        } catch (ParseException | IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}


//This class contains methods for addind and renewing Recipient objects
class Add_Recipients {
    public static Date StringToDate(String datesrting) throws ParseException {
        return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
    }

    //method to create new Recipient objects
    public static Recipients addRecipients(String[] type_details, String[] name_email) throws ParseException {
        switch (type_details[0]) {
            case "Personal":
                return new Personal_Recipints(type_details[0], name_email[0], name_email[1], name_email[2],
                        StringToDate(name_email[3]));

            case "Office_friend":
                return new Official_Personal_Recipients(type_details[0], name_email[0], name_email[1], name_email[2],
                        StringToDate(name_email[3]));
            case "Official":
                return new Official_Recipients(type_details[0], name_email[0], name_email[1], name_email[2]);

            default:
                System.out.println("Invalid Recipient Type");

        }
        return null;
    }

    //method to nenewing the previously entered Recipient objects
    public static Recipients renewRecipients(Recipients pastRecipient) throws ParseException {
        if (pastRecipient.getType().equals("Personal")) {
            Personal_Recipints newRecipient = (Personal_Recipints) pastRecipient;
            return new Personal_Recipints(pastRecipient.getType(), pastRecipient.getName(),
                    ((Personal_Recipints) pastRecipient).getNickname(), pastRecipient.getEmail(),
                    ((Personal_Recipints) pastRecipient).getBirthday());

        } else if (pastRecipient.getType().equals("Office_friend")) {
            return new Official_Personal_Recipients(pastRecipient.getType(), pastRecipient.getName(),
                    pastRecipient.getEmail(), ((Official_Personal_Recipients) pastRecipient).getDesignation(),
                    ((Official_Personal_Recipients) pastRecipient).getBirthday());

        } else if (pastRecipient.getType().equals("Official")) {
            return new Official_Recipients(pastRecipient.getType(), pastRecipient.getName(), pastRecipient.getEmail(),
                    ((Official_Recipients) pastRecipient).getDesignation());

        }

        return null;
    }



}

class AlternativeMethods {

    //method to nenewing previosly sent Email objects
    public static Email renewEmailRecords(Email emailrecords) throws ParseException {
        return (new Email(emailrecords.getDate(), emailrecords.getRecipient(), emailrecords.getSubject()));
    }

    public static Date toDaydate() throws ParseException {
        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        return Date.from(zonedDateTime.toInstant());

    }

    public static Date StringToDate(String datesrting) throws ParseException {
        try {
            return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
        } catch (ParseException e) {
            System.out.println("Invalid date format");
        }
        return null;
    }
}


//this class contains methods to check if a wish to a recipient is already sent or not

class Email_Rec_Checker {
    // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
    static Date date;

    static {
        try {
            date = AlternativeMethods.toDaydate();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    //this method checks if a wish to a recipient is already sent or not
    public static boolean isSent(Date birthday, String email, String subject, ArrayList<Object> emailrecords) {
        try {
            if (emailrecords != null) {
                for (Object i : emailrecords) {
                    if (i.getDate().getYear() == date.getYear() && i.getDate().getMonth() == birthday.getMonth() &&
                            i.getDate().getDate() == birthday.getDate() && Objects.equals(subject, i.getSubject()) &&
                            i.getRecipient().equals(email)) {
                        return false;
                    }
                }

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        }


        return true;
    }
}


//this class contains all the methods related to sending an email
class EmailSender {

    //method for sending and email
    public EmailSender() throws IOException, ClassNotFoundException {
        String Path5 = "D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\Mail_Records.txt";

        File newFile = new File(Path5);
        if (newFile.length() != 0) {
            emailrecords = Serialize_Deserialize.DeserializeEmailRecords(Path5);
        }
    }

    static ArrayList<Object> emailrecords = new ArrayList<>();

    public static void setEmailrecords(ArrayList<Object> emailrecords) {
        EmailSender.emailrecords = emailrecords;
    }

    public static void EmailSendereng(String recipient, String mess, String content) throws IOException, ClassNotFoundException {

        final String username = "mohamedmuaadh231@gmail.com";
        final String password = "meyccryjdmbgrrex";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS

        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("mohamedmuaadh231@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(recipient)
            );
            message.setSubject(mess);
            message.setText(content);
            Transport.send(message);


            System.out.println("Done");


        } catch (MessagingException e) {
            e.printStackTrace();
        }


        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        Date utilDate = Date.from(zonedDateTime.toInstant());

        try {
            emailrecords.add(new Email(utilDate, recipient, content));

        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        try {
            Serialize_Deserialize.SerializeEmails(emailrecords);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Object> getEmailrecords() {
        return emailrecords;
    }
}


//class for Official_Personal_Recipients
class Official_Personal_Recipients extends Official_Recipients implements Serializable {

    Date birthday;
    Date last_wished_date = null;

    public Official_Personal_Recipients(String type, String name, String email, String designation, Date birthday) {
        super(type, name, email, designation);
        this.birthday = birthday;
    }

    public Date getBirthday() {
        return birthday;
    }

    public Date getLast_wished_year() {
        return last_wished_date;
    }

    public void setLast_wished_year(Date last_wished_year) {
        this.last_wished_date = last_wished_year;
    }
}


//class for Official_Recipients
class Official_Recipients implements Serializable {


    private final String designation;

    public Official_Recipients(String type, String name, String email, String designation) {
        super(type, name, email);
        this.designation = designation;
    }

    public String getDesignation() {
        return designation;
    }
}

//class for Personal_Recipints
class Personal_Recipints implements Serializable {
    Date birthday;

    Date last_wished_date = null;

    private String nickname;

    public Date getBirthday() {
        return birthday;
    }

    public String getNickname() {
        return nickname;
    }


    public Personal_Recipints(String type, String name, String nickname, String email, Date birthday) {
        super(type, name, email);
        this.birthday = birthday;
        this.nickname = nickname;

    }

    public Date getLast_wished_year() {
        return last_wished_date;
    }

    public void setLast_wished_year(Date last_wished_year) {
        this.last_wished_date = last_wished_year;

    }
}

    //super class for recipients
    class Recipients implements Serializable {
        private String type;
        private String name;
        private String email;

        public Recipients(String type, String name, String email) {
            this.setType(type);
            this.setName(name);
            this.setEmail(email);
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }


    }

    @SuppressWarnings("ALL")
            //this class contains methods for Serializing and deserializing a ArrayList and writing it to a file and retrieving it
    class Serialize_Deserialize {

        //method for serializing an ArrayList of Recipients and writing it
        public static void Serialize(ArrayList<Recipients> recipients) throws IOException {
            try {
                FileOutputStream fos = new FileOutputStream("D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\clientList.ser");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                // write object to file
                oos.writeObject(recipients);
                oos.close();

            } catch (IOException i) {
                i.printStackTrace();
            }
        }


        //method for deserializing an ArrayList of Recipients
        public static ArrayList Deserialize(String Path) throws IOException, ClassNotFoundException {
            ArrayList Recipients = null;
            try {
                FileInputStream is = new FileInputStream(Path);
                ObjectInputStream ois = new ObjectInputStream(is);

                Recipients = (ArrayList) ois.readObject();

                for (Object r : Recipients) {
                    Add_Recipients.renewRecipients((Recipients) r);
                }

                ois.close();
                is.close();


            } catch (IOException i) {
                i.printStackTrace();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            return Recipients;
        }


        //method for serializing an ArrayList of Emails and writing it
        public static void SerializeEmails(ArrayList<Email> emailrecords) throws IOException {
            try {
                FileOutputStream fos = new FileOutputStream("D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\Mail_Records.txt");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                // write object to file
                oos.writeObject(emailrecords);
                oos.close();

            } catch (IOException i) {
                i.printStackTrace();
            }
        }

        //method for deserializing an ArrayList of Emails
        public static ArrayList<Email> DeserializeEmailRecords(String Path) throws IOException, ClassNotFoundException {
            ArrayList<Email> TempEmailRecords = new ArrayList<Email>();

            try {
                FileInputStream is = new FileInputStream(Path);
                ObjectInputStream ois = new ObjectInputStream(is);

                ArrayList<Email> EmailRecords = (ArrayList<Email>) ois.readObject();

                for (Email r : EmailRecords) {
                    TempEmailRecords.add(AlternativeMethods.renewEmailRecords(r));
                }

                ois.close();
                is.close();


            } catch (EOFException e) {
                // ... this is fine
            } catch (IOException i) {
                i.printStackTrace();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            return TempEmailRecords;
        }
    }

    //this class contains methods for starting and restarting the program
    class Start_Restart {

        public static Date dateReturner() {
            // Creating the LocalDatetime object
            LocalDate currentLocalDate = LocalDate.now();

            // Getting system timezone
            ZoneId systemTimeZone = ZoneId.systemDefault();

            // converting LocalDateTime to ZonedDateTime with the system timezone
            ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()


            return Date.from(zonedDateTime.toInstant());
        }

        //this method starts the program by recreating the previously saved Recipient objects
        public static void start(ArrayList<Recipients> recipients) throws ParseException, IOException, NullPointerException,
                ClassNotFoundException {


            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            Date date = dateReturner();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
            String strDate = formatter.format(date);
            ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, strDate);

            for (Recipients recipient : recipients_list) {
                restart(recipient);
            }

        }

        //this methods will check a given Recipient's bithday is on today and if it's today this will call the method to send the email
        // only if previously the wish hasn't been sent
        public static void restart(Recipients recipient) {
            try {
                if (recipient.getType().equals("Personal")) {
                    Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                    if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                            "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                        newRecipient.setLast_wished_year(dateReturner());
                        if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                            EmailSender.EmailSendereng(newRecipient.getEmail(), "Hug and Love on Your Birthday " +
                                    newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                        }
                    }
                } else if (recipient.getType().equals("Office_friend")) {
                    Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                    if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                            "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                        newRecipient.setLast_wished_year(dateReturner());
                        if (isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                            EmailSender.EmailSendereng(newRecipient.getEmail(), "Wish you a Happy Birthday " +
                                    newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                        }
                    }
                }

            } catch (ParseException | IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }





