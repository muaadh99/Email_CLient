package EmailClient;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

public class EmailSender {
    public EmailSender() throws IOException, ClassNotFoundException {
        String Path5 = "D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\Mail_Records.txt";

        File newFile = new File(Path5);
        if(newFile.length() != 0) {
            emailrecords = Serialize_Deserialize.DeserializeEmailRecords(Path5);
        }
    }

    static ArrayList emailrecords = new ArrayList<>();

    public static void setEmailrecords(ArrayList<Email> emailrecords) {
        EmailSender.emailrecords = emailrecords;
    }
    public static void EmailSendereng(String recipient , String mess , String content) throws IOException, ClassNotFoundException {

        final String username = "mohamedmuaadh231@gmail.com";
        final String password = "meyccryjdmbgrrex";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS

        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("mohamedmuaadh231@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(recipient)
            );
            message.setSubject(mess);
            message.setText(content);
            Transport.send(message);


            System.out.println("Done");



        } catch (MessagingException e) {
            e.printStackTrace();
        }


            // Creating the LocalDatetime object
            LocalDate currentLocalDate = LocalDate.now();

            // Getting system timezone
            ZoneId systemTimeZone = ZoneId.systemDefault();

            // converting LocalDateTime to ZonedDateTime with the system timezone
            ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            Date utilDate = Date.from(zonedDateTime.toInstant());

            try{
                emailrecords.add(new Email(utilDate , recipient , content));

        }
        catch(NullPointerException e) {
            e.printStackTrace();
        }
        try{
            Serialize_Deserialize.SerializeEmails(emailrecords);
        }
        catch(NullPointerException e) {
            e.printStackTrace();
        }
    }
    public static ArrayList<Email> getEmailrecords() {
        return emailrecords;
    }
}