package EmailClient;

import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;

@SuppressWarnings("ALL")
public class Serialize_Deserialize {
    public static void Serialize(ArrayList<Recipients> recipients) throws IOException {
        try {
            FileOutputStream fos = new FileOutputStream("D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\clientList.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            // write object to file
            oos.writeObject(recipients);
            oos.close();

        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public static ArrayList Deserialize(String Path) throws IOException, ClassNotFoundException {
        ArrayList Recipients = null;
        try {
            FileInputStream is = new FileInputStream(Path);
            ObjectInputStream ois = new ObjectInputStream(is);

            Recipients = (ArrayList) ois.readObject();

            for(Object r : Recipients) {
                Add_Recipients.renewRecipients((Recipients) r);
            }

            ois.close();
            is.close();

//            for (Object i : Recipients) {
//                System.out.println(i);
//            }


        } catch (IOException i) {
            i.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return Recipients;
    }

    public static void SerializeEmails(ArrayList<Email> emailrecords) throws IOException {
        try {
            FileOutputStream fos = new FileOutputStream("D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\Mail_Records.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            // write object to file
            oos.writeObject(emailrecords);
            oos.close();

        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    public static ArrayList<Email> DeserializeEmailRecords(String Path) throws IOException, ClassNotFoundException {
        ArrayList<Email> TempEmailRecords = new ArrayList<Email>();

        try {
            FileInputStream is = new FileInputStream(Path);
            ObjectInputStream ois = new ObjectInputStream(is);

            ArrayList<Email> EmailRecords = (ArrayList<Email>) ois.readObject();

            for(Email r : EmailRecords) {
                TempEmailRecords.add(Add_Recipients.renewEmailRecords(r));
            }

            ois.close();
            is.close();


        } catch (EOFException e) {
            // ... this is fine
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return TempEmailRecords;
    }
}