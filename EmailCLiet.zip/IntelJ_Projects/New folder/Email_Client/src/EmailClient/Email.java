package EmailClient;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Email implements Serializable {


    Date date ;
    String recipient ;
    String subject;

    public Date getDate() {
        return date;
    }
    public Email(Date date, String recipient, String subject) {
        this.date = date;
        this.recipient = recipient;
        this.subject = subject;
    }
    public String getRecipient() {
        return recipient;
    }

    public String getSubject() {
        return subject;
    }


}
