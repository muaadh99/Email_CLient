package EmailClient;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Birthday_Checker {
    public static Date StringToDate(String datesrting) throws ParseException {
        return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
    }

    public static boolean isBirthday(Date birthday, Date date) {
        if (birthday.getMonth() == date.getMonth() && birthday.getDate() == date.getDate()) {
            return true;
        }
        return false;
    }

    public static ArrayList<Recipients> checkBirthday(ArrayList<Recipients> recipients , String Date) throws ParseException {
        Date date = StringToDate(Date);
        ArrayList<Recipients> recipients_list = new ArrayList<Recipients>();
        for (Recipients recipient : recipients) {
            if (recipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                if (isBirthday(newRecipient.birthday, date)) {
                    recipients_list.add(newRecipient);
                }
            } else if (recipient.getType().equals("Office_friend")) {
                Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                if (isBirthday(newRecipient.birthday, date)) {
                    recipients_list.add(newRecipient);
                }
            }
        }
        return recipients_list;
    }
}
