package EmailClient;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Email_Rec_Checker {
    // Creating the LocalDatetime object
    static LocalDate currentLocalDate = LocalDate.now();

    // Getting system timezone
    static ZoneId systemTimeZone = ZoneId.systemDefault();

    // converting LocalDateTime to ZonedDateTime with the system timezone
    static ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

    // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
    static Date date = Date.from(zonedDateTime.toInstant());
    public static boolean isSent(Date birthday , String email , String subject , ArrayList<Email> emailrecords){
        try{
            if(emailrecords != null) {
                for (Email i : emailrecords) {
                    if (i.getDate().getYear() == date.getYear() && i.getDate().getMonth() == birthday.getMonth() &&
                            i.getDate().getDate() == birthday.getDate() && Objects.equals(subject, i.getSubject())) {
                        return false;
                    }
                }
            }

    }
        catch(NullPointerException e) {
            e.printStackTrace();
        }

        return true;
    }
}
