package EmailClient;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;

public class Start_Restart {

    public static Date dateReturner (){
        // Creating the LocalDatetime object
        LocalDate currentLocalDate = LocalDate.now();

        // Getting system timezone
        ZoneId systemTimeZone = ZoneId.systemDefault();

        // converting LocalDateTime to ZonedDateTime with the system timezone
        ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()


        return Date.from(zonedDateTime.toInstant());
    }
    public static void start(ArrayList<Recipients> recipients) throws ParseException, IOException, NullPointerException,
            ClassNotFoundException {


            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            Date date = dateReturner ();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
            String strDate = formatter.format(date);
            ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, strDate);

            for (Recipients recipient : recipients_list) {
                restart(recipient);
            }

        }

    public static void restart(Recipients recipient){
        try {
            if (recipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday() , newRecipient.getEmail() ,
                        "Hug and Love on Your Birthday " , EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner ());
                    EmailSender.EmailSendereng(newRecipient.getEmail(), "Hug and Love on Your Birthday " +
                            newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                }
            } else if (recipient.getType().equals("Office_friend")) {
                Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                if (Email_Rec_Checker.isSent(newRecipient.getBirthday() , newRecipient.getEmail() ,
                        "Wish you a Happy Birthday " , EmailSender.emailrecords)) {
                    newRecipient.setLast_wished_year(dateReturner ());
                    EmailSender.EmailSendereng(newRecipient.getEmail(), "Wish you a Happy Birthday " +
                            newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}

