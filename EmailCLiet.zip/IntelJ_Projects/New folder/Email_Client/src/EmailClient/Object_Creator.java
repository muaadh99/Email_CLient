package EmailClient;

import java.text.ParseException;
import java.util.ArrayList;

import static EmailClient.Add_Recipients.renewRecipients;

public class Object_Creator {
    public static  ArrayList<Recipients> create(ArrayList<Recipients> recipients ) throws ParseException {
        ArrayList<Recipients> recipients_list = new ArrayList<Recipients>();
        for (Recipients recipient : recipients) {
            renewRecipients(recipient);
        }
        return recipients_list;


    }
}
