package temp;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;


public class temp {



    static class Email_Client_Final {
        public static void main(String[] args) throws IOException, ParseException, ClassNotFoundException {
            System.out.println("Welcome to the Email Client\n" + "Please Be Patient Till Check and Send Wishes for Those who have birthday\n"  );
            ArrayList recipients = new ArrayList<>();
            String ClientPath = "clientList.ser";
            try {
                File myObj = new File(ClientPath);
                if(myObj.length() != 0){
                    recipients = (Serialize_Deserialize.Deserialize(ClientPath));
                }

            }
            catch (IOException | ClassNotFoundException i) {
                i.printStackTrace();
            }

            new EmailSender();
            Start_Restart.start(recipients);

            System.out.println("Ok All Set to Go");


            boolean start = true ;


            // create more classes needed for the implementation (remove the  public access modifier from classes when you submit your code)
            Scanner scanner = null;
            scanner = new Scanner(System.in);
            System.out.println("\nEnter option type: \n"
                    + "1 - Adding a new recipient\n"
                    + "2 - Sending an email\n"
                    + "3 - Printing out all the recipients who have birthdays\n"
                    + "4 - Printing out details of all the emails sent\n"
                    + "5 - Printing out the number of recipient objects in the application\n"
                    + "6 - End the Programme\n");
            int option = 0;
            try {
                option = scanner.nextInt();

            } catch (InputMismatchException e) {
                System.out.println("Invalid Choice");
            }


            switch (option) {
                case 1:
                    // input format - Official: nimal,nimal@gmail.com,ceo
                    // Use a single input to get all the details of a recipient
                    // code to add a new recipient
                    // store details in clientList.txt file
                    // Hint: use methods for reading and writing files
                    System.out.println("input format - Official: nimal,nimal@gmail.com,ceo  or\n" +
                            "               Office_friend: kamal,kamal@gmail.com,clerk,2000/12/12   or\n" +
                            "               Personal: sunil,<nick-name>,sunil@gmail.com,2000/10/10\n");

                    String[] type_details;
                    String[] name_email;

                    Scanner sc = new Scanner(System.in);
                    String details = sc.nextLine();


                    type_details = details.split(": ");
                    try{
                        name_email = type_details[1].split(",");
                    }
                    catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Invalid Input");
                        break;
                    }

                    try {
                        recipients.add(Add_Recipients.addRecipients(type_details, name_email));
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    Serialize_Deserialize.Serialize(recipients);
                    Start_Restart.restart(Objects.requireNonNull(Add_Recipients.addRecipients(type_details, name_email)));
                    System.out.println("Recipient added successfully");

                    String Path1 = "D:\\IntelJ_Projects\\Email_Client\\src\\EmailClient\\clientList.txt";
                    String newdetails = details + "\n";
                    Files.write(Paths.get(Path1), newdetails.getBytes(), StandardOpenOption.APPEND);

                    break;
                case 2:
                    // input format - email, subject, content
                    // code to send an email
                    System.out.println("input format - email, subject, content");
                    Scanner scnew = new Scanner(System.in);
                    String recipient = scnew.nextLine();
                    String[] recarray = recipient.split(", ");
                    try{
                        EmailSender.EmailSendereng(recarray[0], recarray[1], recarray[2]);
                    }
                    catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Invalid Input");
                        break;
                    }

                    break;
                case 3:
                    // input format - yyyy/MM/dd (ex: 2018/09/17)
                    // code to print recipients who have birthdays on the given date
                    System.out.println("input format - yyyy/MM/dd (ex: 2018/09/17)");
                    Scanner scc = new Scanner(System.in);
                    String date = scc.nextLine();
                    ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, date);

                    for (Recipients r : recipients_list) {
                        System.out.println(r.getName() + " " + r.getEmail());
                    }

                    break;
                case 4:
                    // input format - yyyy/MM/dd (ex: 2018/09/17)
                    // code to print the details of all the emails sent on the input date
                    System.out.println("input format - yyyy/MM/dd (ex: 2018/09/17)");
                    Scanner sccc = new Scanner(System.in);
                    String datee = sccc.nextLine();

                    try {
                        if(AlternativeMethods.StringToDate(datee) == null){
                            break;
                        }
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }

                    try {
                        for (Email e : EmailSender.getEmailrecords()) {

                            if (e.getDate().equals(Birthday_Checker.StringToDate(datee))) {
                                System.out.println(e.getRecipient() + " " + e.getSubject());
                            }
                        }
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    }

                    break;
                case 5:
                    // code to print the number of recipient objects in the application

                    System.out.println(recipients.size());
                    break;

                case 6:
                    start = false;
            }

            // start email client
            // code to create objects for each recipient in clientList.txt
            // use necessary variables, methods and classes

        }

    }
    class Email implements Serializable {

        /**
         *
         */
        Date date ;
        String recipient ;

        String subject;

        public Date getDate() {
            return date;
        }
        public Email(Date date, String recipient, String subject) {
            this.date = date;
            this.recipient = recipient;
            this.subject = subject;
        }
        public String getRecipient() {
            return recipient;
        }

        public String getSubject() {
            return subject;
        }


    }
    static class Add_Recipients {
        public static Date StringToDate(String datesrting) throws ParseException {
            return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
        }

        //method to create new Recipient objects
        public static Recipients addRecipients(String[] type_details, String[] name_email) throws ParseException {
            switch (type_details[0]) {
                case "Personal":
                    return new Personal_Recipints(type_details[0], name_email[0], name_email[1], name_email[2],
                            StringToDate(name_email[3]) );

                case "Office_friend":
                    return new Official_Personal_Recipients(type_details[0], name_email[0], name_email[1], name_email[2],
                            StringToDate(name_email[3]) );
                case "Official":
                    return new Official_Recipients(type_details[0], name_email[0], name_email[1], name_email[2]);

                default:
                    System.out.println("Invalid Recipient Type");

            }
            return null;
        }

        //method to nenewing the previously entered Recipient objects
        public static void renewRecipients(Recipients pastRecipient) throws ParseException {
            if (pastRecipient.getType().equals("Personal")) {
                Personal_Recipints newRecipient = (Personal_Recipints) pastRecipient;
                new Personal_Recipints(pastRecipient.getType(), pastRecipient.getName(),
                        ((Personal_Recipints) pastRecipient).getNickname(), pastRecipient.getEmail(),
                        ((Personal_Recipints) pastRecipient).getBirthday());

            } else if (pastRecipient.getType().equals("Office_friend")) {
                new Official_Personal_Recipients(pastRecipient.getType(), pastRecipient.getName(),
                        pastRecipient.getEmail(), ((Official_Personal_Recipients) pastRecipient).getDesignation(),
                        ((Official_Personal_Recipients) pastRecipient).getBirthday());

            } else if (pastRecipient.getType().equals("Official")) {
                new Official_Recipients(pastRecipient.getType(), pastRecipient.getName(), pastRecipient.getEmail(),
                        ((Official_Recipients) pastRecipient).getDesignation());

            }

        }
    }




    static class AlternativeMethods {

        //method to nenewing previosly sent Email objects
        public static Email renewEmailRecords(Email emailrecords) throws ParseException {
            return (new Email(emailrecords.getDate() , emailrecords.getRecipient() , emailrecords.getSubject()));
        }

        public static Date toDaydate () throws ParseException {
            // Creating the LocalDatetime object
            LocalDate currentLocalDate = LocalDate.now();

            // Getting system timezone
            ZoneId systemTimeZone = ZoneId.systemDefault();

            // converting LocalDateTime to ZonedDateTime with the system timezone
            ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            return Date.from(zonedDateTime.toInstant());

        }
        public static Date StringToDate(String datesrting) throws ParseException {
            try {
                return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
            } catch (ParseException e) {
                System.out.println("Invalid date format");
            }
            return null;
        }
    }
    static class Birthday_Checker {
        public static Date StringToDate(String datesrting) throws ParseException {
            try {
                return new SimpleDateFormat("yyyy/MM/dd").parse(datesrting);
            } catch (ParseException e) {
                System.out.println("Invalid date format");
            }
            return null;
        }

        //method to check if the birthday is on a given date or not
        public static boolean isBirthday(Date birthday, Date date) {
            if(date != null) {
                if (birthday.getMonth() == date.getMonth() && birthday.getDate() == date.getDate()) {
                    return true;
                }
            }
            return false;
        }

        //method to return a list of recipients who have birthday on a given date
        public static ArrayList<Recipients> checkBirthday(ArrayList<Recipients> recipients , String Date) throws ParseException {
            Date date = StringToDate(Date);
            ArrayList<Recipients> recipients_list = new ArrayList<Recipients>();
            for (Recipients recipient : recipients) {
                if (recipient.getType().equals("Personal")) {
                    Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                    if (isBirthday(newRecipient.birthday, date)) {
                        recipients_list.add(newRecipient);
                    }
                } else if (recipient.getType().equals("Office_friend")) {
                    Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                    if (isBirthday(newRecipient.birthday, date)) {
                        recipients_list.add(newRecipient);
                    }
                }
            }
            return recipients_list;
        }
    }
    static class Email_Rec_Checker {
        // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
        static Date date;

        static {
            try {
                date = AlternativeMethods.toDaydate();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }

        //this method checks if a wish to a recipient is already sent or not
        public static boolean isSent(Date birthday , String email , String subject , ArrayList<Email> emailrecords){
            try{
                if(emailrecords != null) {
                    for (Email i : emailrecords) {
                        if (i.getDate().getYear() == date.getYear() && i.getDate().getMonth() == birthday.getMonth() &&
                                i.getDate().getDate() == birthday.getDate() && Objects.equals(subject, i.getSubject()) &&
                                i.getRecipient().equals(email)) {
                            return false;
                        }
                    }

                }

            }
            catch(NullPointerException e) {
                e.printStackTrace();
            }


            return true;
        }
    }
    static class EmailSender {

        //method for sending and email
        public EmailSender() throws IOException, ClassNotFoundException {
            String Path5 = "Mail_Records.txt";

            File newFile = new File(Path5);
            if (newFile.length() != 0) {
                emailrecords = Serialize_Deserialize.DeserializeEmailRecords(Path5);
            }
        }

        static ArrayList emailrecords = new ArrayList<>();

        public static void setEmailrecords(ArrayList<Email> emailrecords) {
            EmailSender.emailrecords = emailrecords;
        }

        public static void EmailSendereng(String recipient, String mess, String content) throws IOException, ClassNotFoundException {

            final String username = "mohamedmuaadh231@gmail.com";
            final String password = "meyccryjdmbgrrex";

            Properties prop = new Properties();
            prop.put("mail.smtp.host", "smtp.gmail.com");
            prop.put("mail.smtp.port", "587");
            prop.put("mail.smtp.auth", "true");
            prop.put("mail.smtp.starttls.enable", "true"); //TLS

            Session session = Session.getInstance(prop,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                        }
                    });

            try {

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("mohamedmuaadh231@gmail.com"));
                message.setRecipients(
                        Message.RecipientType.TO,
                        InternetAddress.parse(recipient)
                );
                message.setSubject(mess);
                message.setText(content);
                Transport.send(message);


                System.out.println("Done");


            } catch (MessagingException e) {
                e.printStackTrace();
            }


            // Creating the LocalDatetime object
            LocalDate currentLocalDate = LocalDate.now();

            // Getting system timezone
            ZoneId systemTimeZone = ZoneId.systemDefault();

            // converting LocalDateTime to ZonedDateTime with the system timezone
            ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            Date utilDate = Date.from(zonedDateTime.toInstant());

            try {
                emailrecords.add(new Email(utilDate, recipient, content));

            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            try {
                Serialize_Deserialize.SerializeEmails(emailrecords);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }

        public static ArrayList<Email> getEmailrecords() {
            return emailrecords;
        }
    }
    //class for Official_Personal_Recipients
    class Official_Personal_Recipients extends Official_Recipients implements Serializable {

        /**
         *
         */
        private static final long serialVersionUID = 1L;
        Date birthday ;
        Date last_wished_date = null ;

        public Official_Personal_Recipients(String type, String name, String email, String designation , Date birthday ) {
            super(type, name, email, designation);
            this.birthday = birthday;
        }
        public Date getBirthday() {
            return birthday;
        }

        public Date getLast_wished_year() {
            return last_wished_date;
        }

        public void setLast_wished_year(Date last_wished_year) {
            this.last_wished_date = last_wished_year;
        }
    }
    class Official_Recipients extends Recipients implements Serializable {


        /**
         *
         */
        private static final long serialVersionUID = 1L;
        private final String designation ;

        public Official_Recipients(String type, String name, String email, String designation) {
            super(type, name, email);
            this.designation = designation;
        }
        public String getDesignation() {
            return designation;
        }
    }

    class Personal_Recipints extends Recipients implements Serializable {
        /**
         *
         */
        private static final long serialVersionUID = 1L;

        Date birthday ;

        Date last_wished_date = null ;

        private String nickname ;

        public Date getBirthday() {
            return birthday;
        }

        public String getNickname() {
            return nickname;
        }



        public Personal_Recipints(String type, String name,String nickname , String email, Date birthday  ) {
            super(type, name, email);
            this.birthday = birthday;
            this.nickname = nickname;

        }
        public Date getLast_wished_year() {
            return last_wished_date;
        }

        public void setLast_wished_year(Date last_wished_year) {
            this.last_wished_date = last_wished_year;

        }
    }
    class Recipients implements Serializable {
        /**
         *
         */
        private static final long serialVersionUID = 1L;
        private String type;
        private String name ;
        private String email ;

        public Recipients(String type, String name, String email) {
            this.setType(type);
            this.setName(name);
            this.setEmail(email);
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }


    }
    //this class contains methods for Serializing and deserializing a ArrayList and writing it to a file and retrieving it
    static class Serialize_Deserialize {

        //method for serializing an ArrayList of Recipients and writing it
        public static void Serialize(ArrayList<Recipients> recipients) throws IOException {
            try {
                FileOutputStream fos = new FileOutputStream("clientList.ser");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                // write object to file
                oos.writeObject(recipients);
                oos.close();

            } catch (IOException i) {
                i.printStackTrace();
            }
        }


        //method for deserializing an ArrayList of Recipients
        public static ArrayList Deserialize(String Path) throws IOException, ClassNotFoundException {
            ArrayList Recipients = null;
            try {
                FileInputStream is = new FileInputStream(Path);
                ObjectInputStream ois = new ObjectInputStream(is);

                Recipients = (ArrayList) ois.readObject();

                for (Object r : Recipients) {
                    Add_Recipients.renewRecipients((Recipients) r);
                }

                ois.close();
                is.close();

                //	            for (Object i : Recipients) {
                //	                System.out.println(i);
                //	            }


            } catch (IOException i) {
                i.printStackTrace();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            return Recipients;
        }


        //method for serializing an ArrayList of Emails and writing it
        public static void SerializeEmails(ArrayList<Email> emailrecords) throws IOException {
            try {
                FileOutputStream fos = new FileOutputStream("Mail_Records.txt");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                // write object to file
                oos.writeObject(emailrecords);
                oos.close();

            } catch (IOException i) {
                i.printStackTrace();
            }
        }

        //method for deserializing an ArrayList of Emails
        public static ArrayList<Email> DeserializeEmailRecords(String Path) throws IOException, ClassNotFoundException {
            ArrayList<Email> TempEmailRecords = new ArrayList<Email>();

            try {
                FileInputStream is = new FileInputStream(Path);
                ObjectInputStream ois = new ObjectInputStream(is);

                ArrayList<Email> EmailRecords = (ArrayList<Email>) ois.readObject();

                for (Email r : EmailRecords) {
                    TempEmailRecords.add(AlternativeMethods.renewEmailRecords(r));
                }

                ois.close();
                is.close();


            } catch (EOFException e) {
                // ... this is fine
            } catch (IOException i) {
                i.printStackTrace();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            return TempEmailRecords;
        }
    }
    static class Start_Restart {

        public static Date dateReturner() {
            // Creating the LocalDatetime object
            LocalDate currentLocalDate = LocalDate.now();

            // Getting system timezone
            ZoneId systemTimeZone = ZoneId.systemDefault();

            // converting LocalDateTime to ZonedDateTime with the system timezone
            ZonedDateTime zonedDateTime = currentLocalDate.atStartOfDay(systemTimeZone);

            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()


            return Date.from(zonedDateTime.toInstant());
        }

        //this method starts the program by recreating the previously saved Recipient objects
        public static void start(ArrayList<Recipients> recipients) throws ParseException, IOException, NullPointerException,
                ClassNotFoundException {


            // converting ZonedDateTime to Date using Date.from() and ZonedDateTime.toInstant()
            Date date = dateReturner();

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
            String strDate = formatter.format(date);
            ArrayList<Recipients> recipients_list = Birthday_Checker.checkBirthday(recipients, strDate);

            for (Recipients recipient : recipients_list) {
                restart(recipient);
            }

        }

        //this methods will check a given Recipient's bithday is on today and if it's today this will call the method to send the email
        // only if previously the wish hasn't been sent
        public static void restart(Recipients recipient) {
            try {
                if (recipient.getType().equals("Personal")) {
                    Personal_Recipints newRecipient = (Personal_Recipints) recipient;
                    if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                            "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                        newRecipient.setLast_wished_year(dateReturner());
                        if (Birthday_Checker.isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                            EmailSender.EmailSendereng(newRecipient.getEmail(), "Hug and Love on Your Birthday " +
                                    newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                        }
                    }
                } else if (recipient.getType().equals("Office_friend")) {
                    Official_Personal_Recipients newRecipient = (Official_Personal_Recipients) recipient;
                    if (Email_Rec_Checker.isSent(newRecipient.getBirthday(), newRecipient.getEmail(),
                            "Happy Birthday! \n Muaadh", EmailSender.emailrecords)) {
                        newRecipient.setLast_wished_year(dateReturner());
                        if (Birthday_Checker.isBirthday(newRecipient.birthday, AlternativeMethods.toDaydate())) {
                            EmailSender.EmailSendereng(newRecipient.getEmail(), "Wish you a Happy Birthday " +
                                    newRecipient.getName() + "!", "Happy Birthday! \n Muaadh");
                        }
                    }
                }

            } catch (ParseException | IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
}






